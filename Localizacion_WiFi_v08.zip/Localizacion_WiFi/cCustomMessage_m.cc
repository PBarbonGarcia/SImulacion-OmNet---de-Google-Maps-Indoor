//
// Generated file, do not edit! Created by opp_msgc 4.3 from cCustomMessage.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "cCustomMessage_m.h"

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




Register_Class(cCustomMessage);

cCustomMessage::cCustomMessage(const char *name, int kind) : cMessage(name,kind)
{
    this->origin_var = 0;
    this->power_var = 0;
    this->frequency_var = 0;
    for (unsigned int i=0; i<2; i++)
        this->appos_var[i] = 0;
    this->maxobstaclelosses_var = 0;
    this->obstaclelosses_var = 0;
}

cCustomMessage::cCustomMessage(const cCustomMessage& other) : cMessage(other)
{
    copy(other);
}

cCustomMessage::~cCustomMessage()
{
}

cCustomMessage& cCustomMessage::operator=(const cCustomMessage& other)
{
    if (this==&other) return *this;
    cMessage::operator=(other);
    copy(other);
    return *this;
}

void cCustomMessage::copy(const cCustomMessage& other)
{
    this->origin_var = other.origin_var;
    this->power_var = other.power_var;
    this->frequency_var = other.frequency_var;
    for (unsigned int i=0; i<2; i++)
        this->appos_var[i] = other.appos_var[i];
    this->maxobstaclelosses_var = other.maxobstaclelosses_var;
    this->obstaclelosses_var = other.obstaclelosses_var;
}

void cCustomMessage::parsimPack(cCommBuffer *b)
{
    cMessage::parsimPack(b);
    doPacking(b,this->origin_var);
    doPacking(b,this->power_var);
    doPacking(b,this->frequency_var);
    doPacking(b,this->appos_var,2);
    doPacking(b,this->maxobstaclelosses_var);
    doPacking(b,this->obstaclelosses_var);
}

void cCustomMessage::parsimUnpack(cCommBuffer *b)
{
    cMessage::parsimUnpack(b);
    doUnpacking(b,this->origin_var);
    doUnpacking(b,this->power_var);
    doUnpacking(b,this->frequency_var);
    doUnpacking(b,this->appos_var,2);
    doUnpacking(b,this->maxobstaclelosses_var);
    doUnpacking(b,this->obstaclelosses_var);
}

int cCustomMessage::getOrigin() const
{
    return origin_var;
}

void cCustomMessage::setOrigin(int origin)
{
    this->origin_var = origin;
}

int cCustomMessage::getPower() const
{
    return power_var;
}

void cCustomMessage::setPower(int power)
{
    this->power_var = power;
}

int cCustomMessage::getFrequency() const
{
    return frequency_var;
}

void cCustomMessage::setFrequency(int frequency)
{
    this->frequency_var = frequency;
}

unsigned int cCustomMessage::getApposArraySize() const
{
    return 2;
}

double cCustomMessage::getAppos(unsigned int k) const
{
    if (k>=2) throw cRuntimeError("Array of size 2 indexed by %lu", (unsigned long)k);
    return appos_var[k];
}

void cCustomMessage::setAppos(unsigned int k, double appos)
{
    if (k>=2) throw cRuntimeError("Array of size 2 indexed by %lu", (unsigned long)k);
    this->appos_var[k] = appos;
}

double cCustomMessage::getMaxobstaclelosses() const
{
    return maxobstaclelosses_var;
}

void cCustomMessage::setMaxobstaclelosses(double maxobstaclelosses)
{
    this->maxobstaclelosses_var = maxobstaclelosses;
}

double cCustomMessage::getObstaclelosses() const
{
    return obstaclelosses_var;
}

void cCustomMessage::setObstaclelosses(double obstaclelosses)
{
    this->obstaclelosses_var = obstaclelosses;
}

class cCustomMessageDescriptor : public cClassDescriptor
{
  public:
    cCustomMessageDescriptor();
    virtual ~cCustomMessageDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(cCustomMessageDescriptor);

cCustomMessageDescriptor::cCustomMessageDescriptor() : cClassDescriptor("cCustomMessage", "cMessage")
{
}

cCustomMessageDescriptor::~cCustomMessageDescriptor()
{
}

bool cCustomMessageDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<cCustomMessage *>(obj)!=NULL;
}

const char *cCustomMessageDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int cCustomMessageDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 6+basedesc->getFieldCount(object) : 6;
}

unsigned int cCustomMessageDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<6) ? fieldTypeFlags[field] : 0;
}

const char *cCustomMessageDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "origin",
        "power",
        "frequency",
        "appos",
        "maxobstaclelosses",
        "obstaclelosses",
    };
    return (field>=0 && field<6) ? fieldNames[field] : NULL;
}

int cCustomMessageDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='o' && strcmp(fieldName, "origin")==0) return base+0;
    if (fieldName[0]=='p' && strcmp(fieldName, "power")==0) return base+1;
    if (fieldName[0]=='f' && strcmp(fieldName, "frequency")==0) return base+2;
    if (fieldName[0]=='a' && strcmp(fieldName, "appos")==0) return base+3;
    if (fieldName[0]=='m' && strcmp(fieldName, "maxobstaclelosses")==0) return base+4;
    if (fieldName[0]=='o' && strcmp(fieldName, "obstaclelosses")==0) return base+5;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *cCustomMessageDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
        "double",
        "double",
        "double",
    };
    return (field>=0 && field<6) ? fieldTypeStrings[field] : NULL;
}

const char *cCustomMessageDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int cCustomMessageDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    cCustomMessage *pp = (cCustomMessage *)object; (void)pp;
    switch (field) {
        case 3: return 2;
        default: return 0;
    }
}

std::string cCustomMessageDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    cCustomMessage *pp = (cCustomMessage *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getOrigin());
        case 1: return long2string(pp->getPower());
        case 2: return long2string(pp->getFrequency());
        case 3: return double2string(pp->getAppos(i));
        case 4: return double2string(pp->getMaxobstaclelosses());
        case 5: return double2string(pp->getObstaclelosses());
        default: return "";
    }
}

bool cCustomMessageDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    cCustomMessage *pp = (cCustomMessage *)object; (void)pp;
    switch (field) {
        case 0: pp->setOrigin(string2long(value)); return true;
        case 1: pp->setPower(string2long(value)); return true;
        case 2: pp->setFrequency(string2long(value)); return true;
        case 3: pp->setAppos(i,string2double(value)); return true;
        case 4: pp->setMaxobstaclelosses(string2double(value)); return true;
        case 5: pp->setObstaclelosses(string2double(value)); return true;
        default: return false;
    }
}

const char *cCustomMessageDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    };
    return (field>=0 && field<6) ? fieldStructNames[field] : NULL;
}

void *cCustomMessageDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    cCustomMessage *pp = (cCustomMessage *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


