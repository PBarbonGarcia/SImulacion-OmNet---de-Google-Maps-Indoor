/*
 * User.cc
 *
 *  Created on: 26/11/2013
 *      Author: Usuario
 */

#include <string.h>
#include <omnetpp.h>

#include <cCustomMessage_m.h>

class User : public cSimpleModule
{
    private:
        cCustomMessage *Usermsg0;
        cCustomMessage *Usermsg1;
        cCustomMessage *Usermsg2;
    protected:
        double appos[3][2];//posici�n de los accesspoints en metros
        double distance[3];//distancia calculada del accesspoint al usuario en metros
        double pos[2];//posicion del usuario en metros
        virtual void getPosition();//Obtiene la posici�n del usuario
        virtual void saveDistance(cCustomMessage *msg, int i);//Guarda las distancias con los puntos de acceso
        virtual void advisePosition();//Anuncia la posici�n del usuario
        virtual void adjustDistances();//Ajusta las circunferencias para que lleguen a cortarse
        virtual void initialize();
        virtual void handleMessage(cMessage *msg);
};

Define_Module(User);

void User::initialize(){
    distance[0]=distance[1]=distance[2]=0;
    Usermsg0=new cCustomMessage("Usermsg");//Creamos los mensajes de peticion
    Usermsg1=new cCustomMessage("Usermsg");
    Usermsg2=new cCustomMessage("Usermsg");
    const char* temp = getName();
    Usermsg0->setOrigin(atoi(temp+4));//Indicamos el origen del mensaje
    Usermsg1->setOrigin(atoi(temp+4));
    Usermsg2->setOrigin(atoi(temp+4));
    cMessage *msg=new cMessage();
    scheduleAt(0.0,msg);
}

void User::handleMessage(cMessage *msg)
{
    if(msg->isSelfMessage()){
        const char* temp = getName();
        EV<< "User " << atoi(temp+4) << " sending messages to accesspoints.\n";
        send(Usermsg0,"g$o",0);//Envia un mensaje de peticion de respuesta a 3 puntos de acceso
        send(Usermsg1,"g$o",1);
        send(Usermsg2,"g$o",2);
    }
    else{
        cCustomMessage *custommsg = check_and_cast<cCustomMessage *>(msg);
        if(distance[0]==0){//Llega un primer mensaje
            EV << "1 Message arrived.\n";
            saveDistance(custommsg,0);//Recogemos el dato
        }
        else{
            if(distance[1]==0){//Llega un segundo mensaje
                EV << "2 Messages arrived.\n";
                saveDistance(custommsg,1);//Recogemos el dato
            }
            else{//Llega un tercer mensaje
                EV << "3 Messages arrived.\n";
                saveDistance(custommsg,2);//Recogemos el dato
                getPosition();//Localizamos la posicion
                advisePosition();//Anunciamos la posicion
            }
        }
    }
    delete(msg);
}

void User::getPosition()
{
    //Funci�n getPosition, calcula la intersecci�n de tres circunferencias y nos da
    //el punto de corte, que ser� las coordenadas X,Y donde se encuentre el usuario
    double XY1[2];//Cambiamos las variables para adaptarlas a la funcion
    double XY2[2];
    double XY3[2];
    XY1[0]=appos[0][0];
    XY1[1]=appos[0][1];
    XY2[0]=appos[1][0];
    XY2[1]=appos[1][1];
    XY3[0]=appos[2][0];
    XY3[1]=appos[2][1];

    double maxerror=par("maxerror");//Determinamos el m�ximo error en la posici�n del usuario

    adjustDistances();//Ajustamos las circunferencias para que se corten entre ellas

    double d1=distance[0];//Establecemos los radios de circunferencias obtenidos
    double d2=distance[1];
    double d3=distance[2];

    double P1[2];//Creamos los posibles puntos a guardar
    double P2[2];
    double P3[2];
    double P4[2];

    double X1=(pow(XY1[0],2) + pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2) - pow(d1,2) + pow(d2,2) - (XY1[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY2[0],2) + pow(XY1[0],2)*XY2[1] - XY1[1]*pow(XY2[1],2) - pow(XY1[1],2)*XY2[1] + pow(XY2[0],2)*XY2[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY2[1] + pow(d2,2)*XY1[1] - pow(d2,2)*XY2[1] + pow(XY1[1],3) + pow(XY2[1],3) - XY1[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) + XY2[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - 2*XY1[0]*XY1[1]*XY2[0] - 2*XY1[0]*XY2[0]*XY2[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY2[1] - 2*XY1[0]*XY2[0] + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2)) + (XY2[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY2[0],2) + pow(XY1[0],2)*XY2[1] - XY1[1]*pow(XY2[1],2) - pow(XY1[1],2)*XY2[1] + pow(XY2[0],2)*XY2[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY2[1] + pow(d2,2)*XY1[1] - pow(d2,2)*XY2[1] + pow(XY1[1],3) + pow(XY2[1],3) - XY1[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) + XY2[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - 2*XY1[0]*XY1[1]*XY2[0] - 2*XY1[0]*XY2[0]*XY2[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY2[1] - 2*XY1[0]*XY2[0] + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2)))/(2*XY1[0] - 2*XY2[0]);
    double X2=(pow(XY1[0],2) + pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2) - pow(d1,2) + pow(d2,2) - (XY1[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY2[0],2) + pow(XY1[0],2)*XY2[1] - XY1[1]*pow(XY2[1],2) - pow(XY1[1],2)*XY2[1] + pow(XY2[0],2)*XY2[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY2[1] + pow(d2,2)*XY1[1] - pow(d2,2)*XY2[1] + pow(XY1[1],3) + pow(XY2[1],3) + XY1[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - XY2[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - 2*XY1[0]*XY1[1]*XY2[0] - 2*XY1[0]*XY2[0]*XY2[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY2[1] - 2*XY1[0]*XY2[0] + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2)) + (XY2[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY2[0],2) + pow(XY1[0],2)*XY2[1] - XY1[1]*pow(XY2[1],2) - pow(XY1[1],2)*XY2[1] + pow(XY2[0],2)*XY2[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY2[1] + pow(d2,2)*XY1[1] - pow(d2,2)*XY2[1] + pow(XY1[1],3) + pow(XY2[1],3) + XY1[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - XY2[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - 2*XY1[0]*XY1[1]*XY2[0] - 2*XY1[0]*XY2[0]*XY2[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY2[1] - 2*XY1[0]*XY2[0] + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2)))/(2*XY1[0] - 2*XY2[0]);

    double Y1=(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY2[0],2) + pow(XY1[0],2)*XY2[1] - XY1[1]*pow(XY2[1],2) - pow(XY1[1],2)*XY2[1] + pow(XY2[0],2)*XY2[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY2[1] + pow(d2,2)*XY1[1] - pow(d2,2)*XY2[1] + pow(XY1[1],3) + pow(XY2[1],3) - XY1[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) + XY2[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - 2*XY1[0]*XY1[1]*XY2[0] - 2*XY1[0]*XY2[0]*XY2[1])/(2*(pow(XY1[0],2) - 2*XY1[1]*XY2[1] - 2*XY1[0]*XY2[0] + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2)));
    double Y2=(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY2[0],2) + pow(XY1[0],2)*XY2[1] - XY1[1]*pow(XY2[1],2) - pow(XY1[1],2)*XY2[1] + pow(XY2[0],2)*XY2[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY2[1] + pow(d2,2)*XY1[1] - pow(d2,2)*XY2[1] + pow(XY1[1],3) + pow(XY2[1],3) + XY1[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - XY2[0]*sqrt((pow(d1,2) + 2*d1*d2 + pow(d2,2) + 2*XY1[0]*XY2[0] + 2*XY1[1]*XY2[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY2[0],2) - pow(XY2[1],2))*(- pow(d1,2) + 2*d1*d2 - pow(d2,2) - 2*XY1[0]*XY2[0] - 2*XY1[1]*XY2[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2))) - 2*XY1[0]*XY1[1]*XY2[0] - 2*XY1[0]*XY2[0]*XY2[1])/(2*(pow(XY1[0],2) - 2*XY1[1]*XY2[1] - 2*XY1[0]*XY2[0] + pow(XY1[1],2) + pow(XY2[0],2) + pow(XY2[1],2)));

    P1[0]=X1;//Obtenemos 2 puntos de interseccion entre 2 circunferencias
    P1[1]=Y1;

    P2[0]=X2;
    P2[1]=Y2;

    double X3=(pow(XY1[0],2) + pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2) - pow(d1,2) + pow(d3,2) - (XY1[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY3[0],2) + pow(XY1[0],2)*XY3[1] - XY1[1]*pow(XY3[1],2) - pow(XY1[1],2)*XY3[1] + pow(XY3[0],2)*XY3[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY3[1] + pow(d3,2)*XY1[1] - pow(d3,2)*XY3[1] + pow(XY1[1],3) + pow(XY3[1],3) - XY1[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) + XY3[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - 2*XY1[0]*XY1[1]*XY3[0] - 2*XY1[0]*XY3[0]*XY3[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY3[1] - 2*XY1[0]*XY3[0] + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2)) + (XY3[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY3[0],2) + pow(XY1[0],2)*XY3[1] - XY1[1]*pow(XY3[1],2) - pow(XY1[1],2)*XY3[1] + pow(XY3[0],2)*XY3[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY3[1] + pow(d3,2)*XY1[1] - pow(d3,2)*XY3[1] + pow(XY1[1],3) + pow(XY3[1],3) - XY1[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) + XY3[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - 2*XY1[0]*XY1[1]*XY3[0] - 2*XY1[0]*XY3[0]*XY3[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY3[1] - 2*XY1[0]*XY3[0] + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2)))/(2*XY1[0] - 2*XY3[0]);
    double X4=(pow(XY1[0],2) + pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2) - pow(d1,2) + pow(d3,2) - (XY1[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY3[0],2) + pow(XY1[0],2)*XY3[1] - XY1[1]*pow(XY3[1],2) - pow(XY1[1],2)*XY3[1] + pow(XY3[0],2)*XY3[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY3[1] + pow(d3,2)*XY1[1] - pow(d3,2)*XY3[1] + pow(XY1[1],3) + pow(XY3[1],3) + XY1[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - XY3[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - 2*XY1[0]*XY1[1]*XY3[0] - 2*XY1[0]*XY3[0]*XY3[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY3[1] - 2*XY1[0]*XY3[0] + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2)) + (XY3[1]*(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY3[0],2) + pow(XY1[0],2)*XY3[1] - XY1[1]*pow(XY3[1],2) - pow(XY1[1],2)*XY3[1] + pow(XY3[0],2)*XY3[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY3[1] + pow(d3,2)*XY1[1] - pow(d3,2)*XY3[1] + pow(XY1[1],3) + pow(XY3[1],3) + XY1[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - XY3[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - 2*XY1[0]*XY1[1]*XY3[0] - 2*XY1[0]*XY3[0]*XY3[1]))/(pow(XY1[0],2) - 2*XY1[1]*XY3[1] - 2*XY1[0]*XY3[0] + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2)))/(2*XY1[0] - 2*XY3[0]);

    double Y3=(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY3[0],2) + pow(XY1[0],2)*XY3[1] - XY1[1]*pow(XY3[1],2) - pow(XY1[1],2)*XY3[1] + pow(XY3[0],2)*XY3[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY3[1] + pow(d3,2)*XY1[1] - pow(d3,2)*XY3[1] + pow(XY1[1],3) + pow(XY3[1],3) - XY1[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) + XY3[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - 2*XY1[0]*XY1[1]*XY3[0] - 2*XY1[0]*XY3[0]*XY3[1])/(2*(pow(XY1[0],2) - 2*XY1[1]*XY3[1] - 2*XY1[0]*XY3[0] + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2)));
    double Y4=(pow(XY1[0],2)*XY1[1] + XY1[1]*pow(XY3[0],2) + pow(XY1[0],2)*XY3[1] - XY1[1]*pow(XY3[1],2) - pow(XY1[1],2)*XY3[1] + pow(XY3[0],2)*XY3[1] - pow(d1,2)*XY1[1] + pow(d1,2)*XY3[1] + pow(d3,2)*XY1[1] - pow(d3,2)*XY3[1] + pow(XY1[1],3) + pow(XY3[1],3) + XY1[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - XY3[0]*sqrt((pow(d1,2) + 2*d1*d3 + pow(d3,2) + 2*XY1[0]*XY3[0] + 2*XY1[1]*XY3[1] - pow(XY1[0],2) - pow(XY1[1],2) - pow(XY3[0],2) - pow(XY3[1],2))*(- pow(d1,2) + 2*d1*d3 - pow(d3,2) - 2*XY1[0]*XY3[0] - 2*XY1[1]*XY3[1] + pow(XY1[0],2) + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2))) - 2*XY1[0]*XY1[1]*XY3[0] - 2*XY1[0]*XY3[0]*XY3[1])/(2*(pow(XY1[0],2) - 2*XY1[1]*XY3[1] - 2*XY1[0]*XY3[0] + pow(XY1[1],2) + pow(XY3[0],2) + pow(XY3[1],2)));

    P3[0]=X3;//Obtenemos 2 puntos de interseccion entre 2 circunferencias
    P3[1]=Y3;

    P4[0]=X4;
    P4[1]=Y4;

    EV << "Possible positions: \nP1= x: " << P1[0] << ", y: " << P1[1] << ".\nP2= x: " << P2[0] << ", y: " << P2[1] << ".\nP3= x: " << P3[0] << ", y: " << P3[1] << ".\nP4= x: " << P4[0] << ", y: " << P4[1] << ".\n";

    double P[2];//Variable local para el guardado de la posici�n de usuario

    if (abs(P1[0]-P3[0])<=maxerror&&abs(P1[1]-P3[1])<=maxerror){//Buscamos puntos similares (con un error maximo que permitimos)
        P[0]=P1[0]+(P3[0]-P1[0])/2;
        P[1]=P1[1]+(P3[1]-P1[1])/2;
        EV << "P1 ~= P3\n";
    }
    else{
        if (abs(P2[0]-P4[0])<=maxerror&&abs(P2[1]-P4[1])<=maxerror){
           P[0]=P2[0]+(P4[0]-P2[0])/2;
           P[1]=P2[1]+(P4[1]-P2[1])/2;
           EV << "P2 ~= P4\n";
        }
        else{
          if (abs(P1[0]-P4[0])<=maxerror&&abs(P1[1]-P4[1])<=maxerror){
               P[0]=P1[0]+(P4[0]-P1[0])/2;
               P[1]=P1[1]+(P4[1]-P1[1])/2;
               EV << "P1 ~= P4\n";
          }
          else{
              if (abs(P2[0]-P3[0])<=maxerror&&abs(P2[1]-P3[1])<=maxerror){
                  P[0]=P2[0]+(P3[0]-P2[0])/2;
                  P[1]=P2[1]+(P3[1]-P2[1])/2;
                  EV << "P2 ~= P3\n";
              }
              else{
                  P[0]=-1; //Dado que no puede haber distancias negativas, ponemos este valor para indicar un error
                  P[1]=-1;
              }
          }
        }
    }

    pos[0]=P[0];//Pasamos la posici�n a la variable global
    pos[1]=P[1];

}

void User::saveDistance(cCustomMessage *msg, int i)
{
    //Parte del canal
    double distancetoap=sqrt(pow((atoi(getDisplayString().getTagArg("p",0))-msg->getAppos(0)),2)+pow((atoi(getDisplayString().getTagArg("p",1))-msg->getAppos(1)),2));//Calculo de la distancia real al accesspoint (en metros)
    double losses=(32.45+20*log10(distancetoap/1000)+20*log10(msg->getFrequency())+(msg->getObstaclelosses()));//Calculo de las perdidas de propagacion
    double powerreceived=msg->getPower()-losses;//Potencia de se�al recibida en dBm
    EV << "Power Received: " << powerreceived << " dBm.\n";
    //Parte de la aplicaci�n de usuario
    distance[i]=pow(10,(msg->getPower()-powerreceived-32.45-20*log10(msg->getFrequency())-msg->getMaxobstaclelosses())/20)*1000;//Calculo de la distancia aproximada en metros
    appos[i][0]=msg->getAppos(0);//Guardado de la posicion de accesspoint
    appos[i][1]=msg->getAppos(1);
    EV << "Distance to AccessPoint is " << distance[i] << " m.\n";
    EV << "(Real distance to AccessPoint is " << distancetoap << ").\n";
}

void User::adjustDistances()
{
    double offset1=abs(sqrt(pow(appos[0][0]-appos[1][0],2)+pow(appos[0][1]-appos[1][1],2))-(distance[0]+distance[1]));//Determinamos la distancia entre puntos m�s cercanos de las circunferencias
    double offset2=abs(sqrt(pow(appos[0][0]-appos[2][0],2)+pow(appos[0][1]-appos[2][1],2))-(distance[0]+distance[2]));
    double offset3=abs(sqrt(pow(appos[1][0]-appos[2][0],2)+pow(appos[1][1]-appos[2][1],2))-(distance[1]+distance[2]));
//    if(offset1>offset2){//aumentamos el radio de la circunferencia seg�n la mayor de dichas distancias
//        distance[0]=distance[0]+offset1/2+offset2/10;
//    }
//    else{
//        distance[0]=distance[0]+offset2/2+offset1/10;
//    }
//    if(offset1>offset3){
//        distance[1]=distance[1]+offset1/2+offset3/10;
//    }
//    else{
//        distance[1]=distance[1]+offset3/2+offset1/10;
//    }
//    if(offset2>offset3){
//        distance[2]=distance[2]+offset2/2+offset3/10;
//    }
//    else{
//        distance[2]=distance[2]+offset3/2+offset2/10;
//    }
    double maxoffset;
    if(offset1>=offset2&&offset1>=offset3){
        maxoffset=offset1;
    }
    else{
        if(offset2>=offset1&&offset2>=offset3){
            maxoffset=offset2;
        }
        else{
            maxoffset=offset3;
        }
    }
    distance[0]=distance[0]+(maxoffset/2)*1.1;
    distance[1]=distance[1]+(maxoffset/2)*1.1;
    distance[2]=distance[2]+(maxoffset/2)*1.1;
}

void User::advisePosition()
{
    if(pos[0]<0){
        EV<< "Impossible to determinate your position.\n";
    }
    else{
        EV << "Your position is: x: " << pos[0] << ", y: " << pos[1] <<".\n";
    }
    EV << "Your real position is: x: " << atoi(getDisplayString().getTagArg("p",0)) << ", y: " << atoi(getDisplayString().getTagArg("p",1)) <<".\n";
    if(pos[0]>=0){
        EV << "Error in position is: " << sqrt(pow(pos[0]-atoi(getDisplayString().getTagArg("p",0)),2)+pow(pos[1]-atoi(getDisplayString().getTagArg("p",1)),2)) << " m.\n";
    }
}
