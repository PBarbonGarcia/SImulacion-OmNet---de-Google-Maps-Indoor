/*
 * AccessPoint.cc
 *
 *  Created on: 26/11/2013
 *      Author: Usuario
 */

#include <string.h>
#include <omnetpp.h>

#include <cCustomMessage_m.h>

class AccessPoint : public cSimpleModule
{
    private:
        cCustomMessage *Usermsg;
    protected:
        virtual void handleMessage(cMessage *msg);
};

Define_Module(AccessPoint);

void AccessPoint::handleMessage(cMessage *msg)
{
    cCustomMessage *MsgArrived = check_and_cast<cCustomMessage *>(msg);
    EV << "User message arrived.\n";
    Usermsg=new cCustomMessage("APmsg");
    Usermsg->setPower(par("power"));//Guardado de la potencia de transmisi�n del accesspoint
    Usermsg->setFrequency(par("frequency"));//Guardado de frecuencia de trabajo del accesspoint
    Usermsg->setMaxobstaclelosses(par("maxobstaclelosses"));//Guardado de perdiadas maximas por obstaculos del accesspoint
    switch(MsgArrived->getOrigin()){
        case 0:
            Usermsg->setObstaclelosses(par("obstaclelosses0"));//Guardado de perdidas por obstaculos
            break;
        case 1:
            Usermsg->setObstaclelosses(par("obstaclelosses1"));//Guardado de perdidas por obstaculos
            break;
        case 2:
            Usermsg->setObstaclelosses(par("obstaclelosses2"));//Guardado de perdidas por obstaculos
            break;
        case 3:
            Usermsg->setObstaclelosses(par("obstaclelosses3"));//Guardado de perdidas por obstaculos
            break;
        case 4:
            Usermsg->setObstaclelosses(par("obstaclelosses4"));//Guardado de perdidas por obstaculos
            break;
        case 5:
            Usermsg->setObstaclelosses(par("obstaclelosses5"));//Guardado de perdidas por obstaculos
            break;
        case 6:
            Usermsg->setObstaclelosses(par("obstaclelosses6"));//Guardado de perdidas por obstaculos
            break;
        case 7:
            Usermsg->setObstaclelosses(par("obstaclelosses7"));//Guardado de perdidas por obstaculos
            break;
    }
    Usermsg->setAppos(0,atoi(getDisplayString().getTagArg("p",0)));//Guardado de posicion del accesspoint
    Usermsg->setAppos(1,atoi(getDisplayString().getTagArg("p",1)));
    send(Usermsg,"g$o",(msg->getArrivalGate())->getIndex());
    delete(MsgArrived);
}
